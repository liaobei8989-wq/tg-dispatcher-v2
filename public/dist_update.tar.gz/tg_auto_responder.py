#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
====================================================================
🤖 24/7 Telegram Auto-Responder Daemon (24小时全自动追单/彩金守护守护进程)
====================================================================
1. 24小时常驻后台监听所有 .session 账号收到的新私信 (NewMessage)
2. 只要客户回复（无论过了10分钟、1小时还是隔天），立即自动触发：
   - 第2阶段：100个抗封子域名的彩金文案 + 链接
   - 第3阶段：拟人打字 (Typing 3~6s) + 祝老板中奖/暴富祝福语
3. 智能防重复：每个客户只触发追发一次，避免刷屏打扰客户
====================================================================
"""

import os
import sys
import json
import glob
import asyncio
import random
import re
import time
from datetime import datetime

try:
    from telethon import TelegramClient, events
    from telethon.tl.functions.messages import SetTypingRequest
    from telethon.tl.types import SendMessageTypingAction
except ImportError:
    print("[ERROR] 请先安装 Telethon: pip install telethon pysocks")
    sys.exit(1)

try:
    import socks
except ImportError:
    socks = None

import sqlite3

BANNED_OBSOLETE_PHONES = {'5538988630899', '5538991977854', '5538992304845', '5541987023810', '5586995118207', '5586994687152'}

def is_valid_telethon_session(session_path: str) -> bool:
    """检查文件是否为有效的 Telethon SQLite 数据库文件"""
    try:
        real_path = session_path if session_path.endswith('.session') else f"{session_path}.session"
        if not os.path.exists(real_path) or os.path.getsize(real_path) < 100:
            return False
        with open(real_path, 'rb') as f:
            header = f.read(16)
            if b'SQLite format 3' not in header:
                return False
        conn = sqlite3.connect(real_path, timeout=3.0)
        conn.execute("SELECT 1 FROM sqlite_master LIMIT 1")
        conn.close()
        return True
    except Exception:
        return False

def backup_and_heal_session(session_path: str) -> bool:
    """【SQLite 自动备份机制】启动前自动建立 .session.bak 镜像；若检测到损坏，自动秒级无损还原！"""
    real_path = session_path if session_path.endswith('.session') else f"{session_path}.session"
    bak_path = f"{real_path}.bak"
    
    # 1. 若当前文件健康有效，自动同步创建最新镜像备份
    if is_valid_telethon_session(real_path):
        try:
            shutil.copy2(real_path, bak_path)
            return True
        except Exception:
            return True
            
    # 2. 若当前文件损坏/异常，但存在健康 .bak 镜像，立即自动无损还原救治
    if os.path.exists(bak_path) and is_valid_telethon_session(bak_path):
        try:
            print(f"🛡️ [SQLite 自动自愈系统] 检测到主文件损坏/异常 ({os.path.basename(real_path)})，正在从健康备份 ({os.path.basename(bak_path)}) 秒级无损还原！")
            shutil.copy2(bak_path, real_path)
            return True
        except Exception as heal_err:
            print(f"❌ [自愈还原失败]: {heal_err}")
            
    return is_valid_telethon_session(real_path)

def is_session_locked_by_dispatcher(clean_digits: str) -> bool:
    """【读写分离与锁保护】检查账号当前是否正由调度器 (tg-dispatcher) 独占进行批量发送"""
    candidates = [
        os.path.join(os.getcwd(), "sessions", f".lock_{clean_digits}"),
        f"/root/tg-dispatcher/sessions/.lock_{clean_digits}",
        f"/root/tg-dispatcher-v2/sessions/.lock_{clean_digits}",
        os.path.join(os.getcwd(), "sessions", ".dispatcher_active.lock"),
        "/root/tg-dispatcher/sessions/.dispatcher_active.lock"
    ]
    for lf in candidates:
        if os.path.exists(lf):
            try:
                # 检查锁文件是否超过 10 分钟未更新，防止意外死锁
                mtime = os.path.getmtime(lf)
                if time.time() - mtime > 600:
                    os.unlink(lf)
                    return False
                return True
            except Exception:
                return True
    return False

DEFAULT_API_ID = 2040
DEFAULT_API_HASH = "b18441a1ff607e10a989891a5462e627"

# 100 个抗封子域名池 (从 5 个副域名衍生出 100 个子域名 -> 轮流跳转主网站 -> 7个博彩盘口)
BASE_DOMAINS = ['promobr1.xyz', 'promobr2.xyz', 'promobr3.xyz', 'promobr4.xyz', 'promobr5.xyz']
SUB_PREFIXES = [
    'vip', 'br', 'pix', 'spin', 'bet', 'slot', 'lucky', 'win', 'top', 'go',
    'play', 'forra', 'mega', 'sorte', 'ouro', 'clube', 'brasil', 'premio', 'bonus', 'turbo'
]

ALL_100_SUBDOMAINS = [
    f"https://{prefix}{idx+1:02d}.{dom}/pt"
    for dom in BASE_DOMAINS
    for idx, prefix in enumerate(SUB_PREFIXES)
]

# ==============================================================================
# 🇧🇷 2026 巴西本土实战高转化率话术库 (真人人设 + 免充心智 + Tigrinho 爆款)
# ==============================================================================

# 意图 1：当客户询问身份（"Quem é?", "De onde me conhece?", "Não te conheço", "O que é?"）
INTENT_WHO_ARE_YOU_TEMPLATES = [
    "Haha sou eu do grupo de apostas/slots do Telegram! Vim te avisar porque liberou um saldo teste de R$ 15 a R$ 20 grátis no cadastro hoje 🐯 Sem depósito, se forrar o saque cai direto no seu PIX. Dá uma olhada aqui antes de fecharem: {URL}",
    "Opa, te vi num dos grupos de jogos! Passei pra te avisar que a plataforma nova liberou bônus de teste pro pessoal do TG hoje 🎰💵 Sem pegadinha de depósito, paga no PIX na hora: {URL}",
    "Haha sou jogadora também! Vi seu perfil no grupo e lembrei de mandar: liberou um saldo de cortesia de R$ 15 no cadastro com saque imediato no PIX! O link é esse: {URL}",
    "E aí! Sou eu que te mandei um oi antes. Vim te dar a dica do bônus sem depósito que liberou hoje no Tigrinho 🐯 Aproveita pra rodar de graça: {URL}"
]

# 意图 2：当客户询问玩法/真假/索要链接（"Como funciona?", "É verdade?", "Paga mesmo?", "Quero", "Manda", "Passa o link"）
INTENT_HOW_IT_WORKS_TEMPLATES = [
    "É bem simples mano! É só cadastrar rapidinho pelo link oficial que o saldo teste cai na hora pra você rodar o Tigrinho 🐯 Não precisa pôr dinheiro do bolso, e se forrar o PIX cai em menos de 1 minuto: {URL}",
    "Paga sim chefe, 100% no PIX! O sistema tá dando de R$ 15 a R$ 20 grátis pras primeiras contas hoje. Cria a conta em 30 segundos e vai direto no Fortune Tiger que tá pagando agora: {URL}",
    "Com certeza irmão! Plataforma oficial com saque instantâneo no PIX. Pega seu bônus de cortesia sem depósito aqui e boa forra: {URL}",
    "Super fácil amigo! Clica no link, faz o cadastro básico e o bônus já ativa na conta pra você jogar sem arriscar seu dinheiro: {URL}"
]

# 意图 3：通用回复与问候（"Oi", "Olá", "1", "Bom dia", "Boa tarde", "E aí", 或其他一般回复）
SECOND_MESSAGE_TEMPLATES = [
    "Haha então! Vim te avisar que liberou teste grátis no Tigrinho hoje! 🐯 Tá pagando de R$ 15 a R$ 20 no cadastro com saque direto no PIX sem depósito. Aproveita enquanto tá soltando carta: {URL}",
    "Opa! É que liberou um evento de bônus na plataforma nova hoje! 🎁 De R$ 15 a R$ 20 de cortesia no cadastro com saque rápido no PIX. Testa aí antes que acabe: {URL}",
    "Olha só, liberaram giros de cortesia + saldo no cadastro pra testar hoje! 🎰💵 Sem pegadinha de depósito, o dinheiro cai na hora no PIX se forrar. Confere aqui: {URL}",
    "E aí! Passei pra te avisar do evento dos minutos pagantes no Tigrinho 🐯 Liberou saldo de teste grátis no cadastro pro pessoal rodar e sacar no PIX: {URL}",
    "Haha vi você online e lembrei de te mandar: liberou um saldo de teste de R$ 15 a R$ 20 grátis pra novos cadastros no PIX! 🔥 Dá uma rodada lá: {URL}"
]

# 默认官方沉淀频道/社群（支持环境变量 TG_CHANNEL_LINK 或 sessions/tg_channel.txt 自定义）
DEFAULT_TG_CHANNEL = "https://t.me/brazilgo_chat (@brazilgo_chat)"

def get_tg_channel_link() -> str:
    chan = os.environ.get("TG_CHANNEL_LINK")
    if chan:
        return chan.strip()
    for p in ["sessions/tg_channel.txt", "tg_channel.txt", "/root/tg-dispatcher-v2/sessions/tg_channel.txt"]:
        if os.path.exists(p):
            try:
                with open(p, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    if content:
                        return content
            except Exception:
                pass
    return DEFAULT_TG_CHANNEL

# 第 3 阶段：真人有温度的关照与指导 + 沉淀到官方 TG 频道/社群（100% 可点击完整链接）
THIRD_BLESSING_TEMPLATES = [
    "🎯 Torcendo pelo seu forro hoje! {Se precisar de dicas de slots é só chamar|Bora lucrar muito}! 🎲💎 Não esquece de acompanhar nosso canal VIP de sinais e horários pagantes: 👉 {CHANNEL} 🚀👑",
    "✨ Dica de ouro: joga no Tigrinho na aposta mínima com calma que a cartinha tá solta hoje! 🎰💵 Cola no nosso canal VIP pra não perder os bônus diários: 👉 {CHANNEL} 😉💎",
    "🐯 {Qualquer dúvida me dá um toque aqui que te ajudo a resgatar|Vai com tudo amigo}! E entra também no nosso grupo oficial de estratégias do Tigrinho: 👉 {CHANNEL} {pra pegar os minutos pagantes|onde a gente solta as melhores brechas}! 🍀💵",
    "💸 {Lembrete importante: usa a mesma chave PIX do CPF pro saque cair na hora|Bons giros irmão}! Dá uma passada no nosso grupo VIP de sinais: 👉 {CHANNEL} {Tamo junto|Qualquer dúvida estou por aqui}! 👑✨"
]

def get_random_url() -> str:
    return random.choice(ALL_100_SUBDOMAINS)

def parse_spintax(text: str) -> str:
    if not text:
        return ""
    # 替换各种形式的 URL 占位符或旧静态域名
    rand_url = get_random_url()
    chan_link = get_tg_channel_link()
    text = re.sub(r'\{URL\}|\bURL\b|https?://mostbet\.com/pt|https?://mostbet\.com|https?://brazilgo888\.com/\d+', rand_url, text, flags=re.IGNORECASE)
    text = re.sub(r'\{CHANNEL\}|\bCHANNEL\b', chan_link, text, flags=re.IGNORECASE)
    pattern = re.compile(r'\{([^{}]+)\}')
    while pattern.search(text):
        text = pattern.sub(lambda m: random.choice(m.group(1).split('|')), text)
    return text

# 智能防刷保护（20秒防抖）：防止客户连发两句话时重复回复，但活人每次说话都会必定触发彩金与祝福语
last_reply_timestamps = {}

def check_and_mark_reply(track_key: str, cooldown_seconds: int = 20) -> bool:
    now = time.time()
    last_time = last_reply_timestamps.get(track_key, 0)
    if now - last_time < cooldown_seconds:
        return False
    last_reply_timestamps[track_key] = now
    return True

BRAZIL_DEDICATED_PROXIES = {
    '5586994428117': '200.160.43.132:12323:14aade52b86e6:70dd653fc2',
    '5586994581839': '200.239.213.26:12323:14aade52b86e6:70dd653fc2',
    '5586994709226': '200.160.36.222:12323:14aade52b86e6:70dd653fc2',
    '5586994684213': '200.239.237.124:12323:14aade52b86e6:70dd653fc2',
    '5586994687152': '200.160.38.29:12323:14aade52b86e6:70dd653fc2',
    '5586994850500': '200.152.153.65:12323:14a5a773a873a:4d841434c6',
    '5586994918471': '200.152.154.182:12323:14a5a773a873a:4d841434c6',
    '5586994927293': '200.152.153.188:12323:14a5a773a873a:4d841434c6',
    '5586995118207': '200.152.153.181:12323:14a5a773a873a:4d841434c6',
    '5586995160291': '200.152.155.148:12323:14a5a773a873a:4d841434c6'
}

BRAZIL_PROXY_POOL = [
    '200.160.43.132:12323:14aade52b86e6:70dd653fc2',
    '200.239.213.26:12323:14aade52b86e6:70dd653fc2',
    '200.160.36.222:12323:14aade52b86e6:70dd653fc2',
    '200.239.237.124:12323:14aade52b86e6:70dd653fc2',
    '200.160.38.29:12323:14aade52b86e6:70dd653fc2',
    '200.152.153.65:12323:14a5a773a873a:4d841434c6',
    '200.152.154.182:12323:14a5a773a873a:4d841434c6',
    '200.152.153.188:12323:14a5a773a873a:4d841434c6',
    '200.152.153.181:12323:14a5a773a873a:4d841434c6',
    '200.152.155.148:12323:14a5a773a873a:4d841434c6',
    '200.152.152.137:12323:14abdb1a0db2e:cb8f30f1a9',
    '200.152.152.113:12323:14abdb1a0db2e:cb8f30f1a9',
    '200.152.154.37:12323:14abdb1a0db2e:cb8f30f1a9',
    '200.152.153.126:12323:14abdb1a0db2e:cb8f30f1a9',
    '200.152.154.149:12323:14abdb1a0db2e:cb8f30f1a9',
    '200.152.153.70:12323:14abdb1a0db2e:cb8f30f1a9',
    '200.152.154.77:12323:14abdb1a0db2e:cb8f30f1a9',
    '200.152.152.82:12323:14abdb1a0db2e:cb8f30f1a9',
    '200.152.154.254:12323:14abdb1a0db2e:cb8f30f1a9',
    '200.152.152.175:12323:14abdb1a0db2e:cb8f30f1a9',
    '200.152.152.155:12323:14abdb1a0db2e:cb8f30f1a9',
    '200.152.152.243:12323:14abdb1a0db2e:cb8f30f1a9',
    '200.152.155.124:12323:14abdb1a0db2e:cb8f30f1a9',
    '200.152.152.195:12323:14abdb1a0db2e:cb8f30f1a9',
    '200.152.155.35:12323:14abdb1a0db2e:cb8f30f1a9',
    '200.152.153.232:12323:14abdb1a0db2e:cb8f30f1a9'
]

# Load dynamic proxy pool from proxies.txt if exists
try:
    _ptxt = os.path.join(os.getcwd(), "proxies.txt")
    if os.path.exists(_ptxt):
        with open(_ptxt, "r", encoding="utf-8") as _pf:
            _lines = [l.strip() for l in _pf.readlines() if l.strip()]
            if len(_lines) > 0:
                BRAZIL_PROXY_POOL = _lines
except Exception:
    pass

def load_account_proxies_map():
    # 优先从多路径读取已绑定的代理映射文件
    for p in [
        os.path.join(os.getcwd(), "sessions", "account_proxies.json"),
        os.path.join(os.getcwd(), "account_proxies.json"),
        "/root/tg-dispatcher/sessions/account_proxies.json",
        "/root/tg-dispatcher/account_proxies.json",
        "/root/tg-dispatcher-v2/sessions/account_proxies.json",
        "/root/tg-dispatcher-v2/account_proxies.json"
    ]:
        if os.path.exists(p):
            try:
                with open(p, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if data and isinstance(data, dict):
                        return data
            except Exception:
                pass
    return BRAZIL_DEDICATED_PROXIES

def get_proxy_for_account(session_basename: str, json_cfg: dict = None) -> tuple:
    """智能代理分配器：确保 100% 走独立巴西代理 IP，绝对不漏网走 VPS 原生 IP"""
    # 1. 优先检查 account_proxies.json 权威独立映射
    proxy_map = load_account_proxies_map()
    clean_phone = re.sub(r'[^0-9]', '', session_basename)
    
    proxy_str = proxy_map.get(clean_phone) or proxy_map.get(session_basename)
    if proxy_str:
        parsed = parse_proxy_str(proxy_str)
        if parsed:
            return parsed

    # 2. 检查 json_cfg 中自带的 proxy
    if json_cfg and isinstance(json_cfg.get("proxy"), dict):
        p = json_cfg["proxy"]
        if p.get("addr") and p.get("port"):
            p_str = f"{p.get('addr')}:{p.get('port')}:{p.get('username') or ''}:{p.get('password') or ''}"
            parsed = parse_proxy_str(p_str)
            if parsed:
                return parsed

    # 3. 自动从巴西 60 个独立代理池中按手机号 Hash 唯一分配空闲独享代理（绝不走 VPS 直连）
    try:
        idx = int(clean_phone[-4:]) % len(BRAZIL_PROXY_POOL) if (clean_phone and clean_phone[-4:].isdigit()) else 0
    except Exception:
        idx = hash(session_basename) % len(BRAZIL_PROXY_POOL)
    
    fallback_proxy = BRAZIL_PROXY_POOL[idx]
    return parse_proxy_str(fallback_proxy)

def parse_proxy_str(proxy_str):
    if not proxy_str or not isinstance(proxy_str, str):
        return None
    try:
        raw = proxy_str.strip()
        is_explicit_http = raw.lower().startswith("http://")
        clean = raw.replace("socks5://", "").replace("http://", "")
        parts = clean.split(':')
        if len(parts) < 2:
            return None
        port = int(parts[1])
        # 端口 12323 是典型的 HTTP/HTTPS CONNECT 住宅代理端口 (返回 'H'=72)，或显式指定了 http
        is_http = is_explicit_http or (port == 12323)
        if is_http and socks and hasattr(socks, 'HTTP'):
            ptype = socks.HTTP
        elif socks and hasattr(socks, 'SOCKS5'):
            ptype = socks.SOCKS5
        else:
            ptype = 3 if is_http else 2

        if len(parts) >= 4:
            return (ptype, parts[0], port, True, parts[2], parts[3])
        elif len(parts) == 2:
            return (ptype, parts[0], port)
    except Exception:
        pass
    return None

def save_or_update_replied_customer(session_basename: str, sender_id: str, sender_name: str, incoming_msg: str, username: str = "", phone: str = "", first_name: str = "", last_name: str = "", msg_date_str: str = None):
    """确保将真实已回复客户的完整资料（ID、@username、手机号、全名、接待小号）持久化写入 sessions/replied_customers.json"""
    try:
        possible_dirs = [
            os.path.join(os.getcwd(), "sessions"),
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "sessions"),
            "/var/www/tg-dispatcher-v2/sessions",
            "/root/tg-dispatcher/sessions",
            "/root/tg-dispatcher-v2/sessions"
        ]
        sessions_folder = None
        for p in possible_dirs:
            if os.path.exists(p):
                sessions_folder = p
                break
        if not sessions_folder:
            sessions_folder = os.path.join(os.getcwd(), "sessions")
            os.makedirs(sessions_folder, exist_ok=True)

        replied_cust_file = os.path.join(sessions_folder, "replied_customers.json")
        cust_list = []
        if os.path.exists(replied_cust_file):
            try:
                with open(replied_cust_file, "r", encoding="utf-8") as rf:
                    cust_list = json.load(rf)
                if not isinstance(cust_list, list):
                    cust_list = []
            except Exception:
                cust_list = []

        def is_stale_date(d_str: str) -> bool:
            if not d_str:
                return False
            d_str = str(d_str).strip()
            if d_str.startswith(("2023", "2024", "2025")):
                return True
            try:
                dt = datetime.strptime(d_str[:16], "%Y-%m-%d %H:%M")
                if (datetime.now() - dt).total_seconds() > 48 * 3600:
                    return True
            except Exception:
                pass
            return False

        # 剔除远古历史聊天与旧 demo 数据
        cust_list = [c for c in cust_list if not is_stale_date(c.get("repliedAt", "")) and not str(c.get("repliedAt", "")).startswith("2026-09-06")]

        now_dt = datetime.now()
        date_display = msg_date_str or now_dt.strftime("%Y-%m-%d %H:%M")

        # 若当前会话是 48 小时前的陈旧买号历史会话，坚决不当做营销客资收录
        if is_stale_date(date_display):
            return

        # 检查是否发生在用户前序清空/删除操作之前，绝不唤醒已删除的客资
        cleared_file = os.path.join(sessions_folder, "customers_cleared_at.json")
        if os.path.exists(cleared_file):
            try:
                with open(cleared_file, "r", encoding="utf-8") as cf:
                    cdata = json.load(cf)
                cleared_ts = cdata.get("clearedTimestamp", 0)
                if not cleared_ts and cdata.get("clearedAt"):
                    cleared_ts = datetime.fromisoformat(cdata["clearedAt"].replace('Z', '+00:00')).timestamp() * 1000.0
                if cleared_ts > 0:
                    check_dt = datetime.strptime(date_display[:16], "%Y-%m-%d %H:%M") if date_display else None
                    if check_dt and (check_dt.timestamp() * 1000.0) <= (cleared_ts if cleared_ts > 1e11 else cleared_ts * 1000.0):
                        return # 早于用户清空时间点，已被删除过，不重新入库
            except Exception:
                pass

        clean_username = (username or "").strip()
        if clean_username and not clean_username.startswith("@"):
            clean_username = f"@{clean_username}"

        clean_phone = (phone or "").strip()
        if clean_phone and not clean_phone.startswith("+"):
            clean_phone = f"+{clean_phone}"

        fn = (first_name or "").strip()
        ln = (last_name or "").strip()
        full_name = " ".join([p for p in [fn, ln] if p]).strip() or (sender_name or "").strip() or f"Cliente {sender_id}"

        # 私聊直达链接优先为 t.me/用户名，否则 tg://user?id=...
        direct_link = f"https://t.me/{clean_username.replace('@', '')}" if clean_username else f"tg://user?id={sender_id}"

        existing_idx = -1
        for idx, item in enumerate(cust_list):
            if str(item.get("id")) == str(sender_id):
                existing_idx = idx
                break

        clean_msg = " ".join((incoming_msg or "").replace('\r', ' ').replace('\n', ' ').split()).strip()

        if existing_idx >= 0:
            curr = cust_list[existing_idx]
            if clean_username:
                curr["username"] = clean_username
            if clean_phone:
                curr["phone"] = clean_phone
            if full_name and full_name != f"Cliente {sender_id}":
                curr["fullName"] = full_name
                curr["firstName"] = fn or full_name
            if ln:
                curr["lastName"] = ln
            if clean_msg:
                curr["lastReplyText"] = clean_msg
            curr["receivedByAccount"] = session_basename
            curr["receivedByAccountName"] = f"TG协议号-{session_basename[-4:]}"
            curr["directChatUrl"] = direct_link
            cust_list[existing_idx] = curr
        else:
            new_cust_entry = {
                "id": str(sender_id),
                "username": clean_username,
                "firstName": fn or full_name,
                "lastName": ln,
                "fullName": full_name,
                "phone": clean_phone,
                "receivedByAccount": session_basename,
                "receivedByAccountName": f"TG协议号-{session_basename[-4:]}",
                "lastReplyText": clean_msg or "Oi",
                "repliedAt": date_display,
                "repliedAtIso": now_dt.isoformat(),
                "directChatUrl": direct_link
            }
            cust_list.insert(0, new_cust_entry)

        with open(replied_cust_file, "w", encoding="utf-8") as wf:
            json.dump(cust_list, wf, ensure_ascii=False, indent=2)
            
        print(f"📥 [客资已持久化] ID: {sender_id} | 姓名: {full_name} | @用户名: {clean_username or '(无)'} | 手机: {clean_phone or '(未公开)'}")
    except Exception as e:
        print(f"⚠️ [保存客资信息失败]: {e}")

def record_auto_reply_stat(session_basename: str, sender_id: str, sender_name: str, incoming_msg: str, second_msg: str, url: str, username: str = "", phone: str = "", first_name: str = "", last_name: str = ""):
    """持久化记录 24 小时自动回复与追发彩金统计数据，并实时同步写入真实客资库与聚合收件箱"""
    try:
        possible_dirs = [
            os.path.join(os.getcwd(), "sessions"),
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "sessions"),
            "/var/www/tg-dispatcher-v2/sessions",
            "/root/tg-dispatcher/sessions",
            "/root/tg-dispatcher-v2/sessions"
        ]
        stats_file = None
        sessions_folder = None
        for p in possible_dirs:
            if os.path.exists(p):
                sessions_folder = p
                stats_file = os.path.join(p, "auto_scanner_stats.json")
                break
        if not stats_file:
            sessions_folder = os.path.join(os.getcwd(), "sessions")
            stats_file = os.path.join(sessions_folder, "auto_scanner_stats.json")
            os.makedirs(sessions_folder, exist_ok=True)

        data = {}
        if os.path.exists(stats_file):
            try:
                with open(stats_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
            except Exception:
                data = {}

        now_dt = datetime.now()
        now_str = now_dt.strftime("%Y-%m-%d %H:%M:%S")

        data["todayCount"] = data.get("todayCount", 0) + 1
        data["totalCount"] = data.get("totalCount", 0) + 1
        data["lastScanTime"] = now_str

        if "accountStats" not in data or not isinstance(data["accountStats"], dict):
            data["accountStats"] = {}
        if session_basename not in data["accountStats"]:
            data["accountStats"][session_basename] = {"name": session_basename, "todaySent": 0, "totalSent": 0}

        data["accountStats"][session_basename]["todaySent"] = data["accountStats"][session_basename].get("todaySent", 0) + 1
        data["accountStats"][session_basename]["totalSent"] = data["accountStats"][session_basename].get("totalSent", 0) + 1

        if "logs" not in data or not isinstance(data["logs"], list):
            data["logs"] = []

        log_entry = {
            "timestamp": now_str[11:19],
            "msg": f"账号 +{session_basename} 自动感知客户 {sender_id} ({sender_name or '客户'}) 回复，已成功秒级补发第2条彩金链接",
            "account": session_basename,
            "target": sender_id,
            "incoming": incoming_msg or "Oi",
            "url": url
        }
        data["logs"].insert(0, log_entry)
        data["logs"] = data["logs"][:100]

        with open(stats_file, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

        # 📥 同步持久化写入真实已回复客资库 (replied_customers.json)
        save_or_update_replied_customer(
            session_basename=session_basename,
            sender_id=sender_id,
            sender_name=sender_name,
            incoming_msg=incoming_msg,
            username=username,
            phone=phone,
            first_name=first_name,
            last_name=last_name
        )

        # 💬 同步持久化写入聚合收件箱 (inbox_conversations.json)
        inbox_file = os.path.join(sessions_folder, "inbox_conversations.json")
        inbox_list = []
        if os.path.exists(inbox_file):
            try:
                with open(inbox_file, "r", encoding="utf-8") as ifile:
                    inbox_list = json.load(ifile)
                if not isinstance(inbox_list, list):
                    inbox_list = []
            except Exception:
                inbox_list = []

        # 剔除 demo 数据
        inbox_list = [c for c in inbox_list if not str(c.get("lastMessageTime", "")).startswith("2026-09-06")]

        clean_username = (username or "").strip()
        if clean_username and not clean_username.startswith("@"):
            clean_username = f"@{clean_username}"
        clean_phone = (phone or "").strip()
        if clean_phone and not clean_phone.startswith("+"):
            clean_phone = f"+{clean_phone}"
        fn = (first_name or "").strip()
        ln = (last_name or "").strip()
        full_name = " ".join([p for p in [fn, ln] if p]).strip() or (sender_name or "").strip() or f"Cliente {sender_id}"

        conv_id = f"conv-{sender_id}"
        existing_conv = next((c for c in inbox_list if c.get("id") == conv_id), None)
        cur_ts = now_str[11:16]
        m_in = {
            "id": f"m-in-{int(time.time()*1000)}",
            "conversationId": conv_id,
            "senderType": "customer",
            "senderName": full_name,
            "text": incoming_msg or "Oi",
            "timestamp": cur_ts,
            "status": "delivered"
        }
        m_out = {
            "id": f"m-out-{int(time.time()*1000)+1}",
            "conversationId": conv_id,
            "senderType": "account",
            "senderName": f"TG协议号-{session_basename[-4:]}",
            "text": second_msg,
            "timestamp": cur_ts,
            "status": "read"
        }

        if existing_conv:
            inbox_list.remove(existing_conv)
            existing_conv["unreadCount"] = existing_conv.get("unreadCount", 0) + 1
            existing_conv["lastMessageText"] = incoming_msg or second_msg
            existing_conv["lastMessageTime"] = now_str[:16]
            existing_conv["customerName"] = full_name
            if clean_username:
                existing_conv["customerUsername"] = clean_username
            if clean_phone:
                existing_conv["customerPhone"] = clean_phone
            if "messages" not in existing_conv or not isinstance(existing_conv["messages"], list):
                existing_conv["messages"] = []
            existing_conv["messages"].extend([m_in, m_out])
            inbox_list.insert(0, existing_conv)
        else:
            new_conv = {
                "id": conv_id,
                "customerName": full_name,
                "customerPhone": clean_phone,
                "customerUsername": clean_username,
                "assignedAccountPhone": session_basename,
                "assignedAccountName": f"TG协议号-{session_basename[-4:]}",
                "tag": "hot_lead",
                "unreadCount": 1,
                "lastMessageText": incoming_msg or "Oi",
                "lastMessageTime": now_str[:16],
                "messages": [m_in, m_out]
            }
            inbox_list.insert(0, new_conv)

        with open(inbox_file, "w", encoding="utf-8") as iwf:
            json.dump(inbox_list, iwf, ensure_ascii=False, indent=2)
        print(f"✅ [收件箱同步成功] 客户 {sender_id} ({full_name}) 已实时进入聚合收件箱第一位！")
    except Exception as e:
        print(f"⚠️ [写入客资库与收件箱失败]: {e}")

async def process_and_reply_customer(client, session_basename, chat_id, incoming_msg_id, msg_text, sender_name, username="", phone="", first_name="", last_name="", event=None, peer=None):
    try:
        sender_id = str(chat_id)
        track_key = f"{session_basename}_{sender_id}"

        # 尝试深度抓取客户真实的 TG 详细资料（@username、手机号、全名）
        if not username or not phone or not first_name:
            try:
                user_entity = await client.get_entity(peer or chat_id)
                if user_entity:
                    if not username and getattr(user_entity, 'username', None):
                        username = f"@{user_entity.username}"
                    if not phone and getattr(user_entity, 'phone', None):
                        phone = f"+{user_entity.phone}"
                    if not first_name and getattr(user_entity, 'first_name', None):
                        first_name = user_entity.first_name or ""
                    if not last_name and getattr(user_entity, 'last_name', None):
                        last_name = user_entity.last_name or ""
                    extracted_full = " ".join([p for p in [first_name, last_name] if p]).strip()
                    if extracted_full:
                        sender_name = extracted_full
            except Exception:
                pass

        # 只要客户发言过，立即确保持久化写入客资库（即便是已回复客户也能实时丰富资料）
        save_or_update_replied_customer(
            session_basename=session_basename,
            sender_id=sender_id,
            sender_name=sender_name,
            incoming_msg=msg_text,
            username=username,
            phone=phone,
            first_name=first_name,
            last_name=last_name
        )

        replied_chats_file = os.path.join(os.getcwd(), "sessions", "replied_chats.json")
        replied_history = {}
        if os.path.exists(replied_chats_file):
            try:
                with open(replied_chats_file, "r", encoding="utf-8") as rf:
                    replied_history = json.load(rf)
            except Exception:
                replied_history = {}

        # 兼容处理 last_recorded_id：可能为数值，也可能为 tg_dispatcher 写入的对象字典
        raw_recorded = replied_history.get(track_key, 0)
        last_recorded_id = 0
        if isinstance(raw_recorded, dict):
            last_recorded_id = int(raw_recorded.get("msg_id", 0) or 0)
            if "stage2" in raw_recorded.get("stagesSent", []):
                # 调度器已发送过阶段2，无需二次重复打扰
                return False
        else:
            try:
                last_recorded_id = int(raw_recorded or 0)
            except Exception:
                last_recorded_id = 0

        if incoming_msg_id > 0 and incoming_msg_id <= last_recorded_id:
            return False

        # 检查最新消息是否已真正回复过彩金链接
        try:
            target_for_check = peer or chat_id
            recent_msgs = await client.get_messages(target_for_check, limit=8)
            has_sent_link_after_incoming = False
            if recent_msgs:
                for rm in recent_msgs:
                    if rm and rm.out and rm.id > incoming_msg_id:
                        rm_text = str(getattr(rm, 'message', '') or getattr(rm, 'text', '') or '')
                        # 只有当发出过包含链接或彩金关键词的消息时，才算真正回复完成
                        if 'http' in rm_text or 'promobr' in rm_text or 't.me/' in rm_text or 'Tiger' in rm_text or 'saldo' in rm_text or 'cadastro' in rm_text:
                            has_sent_link_after_incoming = True
                            break
            if has_sent_link_after_incoming:
                replied_history[track_key] = incoming_msg_id
                try:
                    with open(replied_chats_file, "w", encoding="utf-8") as wf:
                        json.dump(replied_history, wf, ensure_ascii=False, indent=2)
                except Exception:
                    pass
                return False
        except Exception:
            pass

        # 20秒防抖，防止同一时间并发调用
        if not check_and_mark_reply(track_key, cooldown_seconds=20):
            return False

        msg_text = str(msg_text or "").strip()
        lower_msg = msg_text.lower()
        print(f"\n📩 [感知客户私聊回复] 账号: +{session_basename} | 客户: {sender_id} ({sender_name or '客户'} | {username or '无@'} | {phone or '无手机'}) | 内容: \"{msg_text}\"")

        # 动态读取 Web 界面配置的话术与开关 (即改即生效)
        custom_cfg = {}
        cfg_file_path = os.path.join(os.getcwd(), "sessions", "auto_responder_config.json")
        if os.path.exists(cfg_file_path):
            try:
                with open(cfg_file_path, "r", encoding="utf-8") as cf:
                    custom_cfg = json.load(cf)
            except Exception:
                custom_cfg = {}

        # 智能客户意图匹配与话术选定
        rand_template = None
        if custom_cfg.get("second_message"):
            rand_template = custom_cfg.get("second_message")
        else:
            if any(k in lower_msg for k in ['quem', 'onde', 'conhece', 'sabe', 'qual e', 'nao te conheco', 'de onde', 'oq e', 'q e isso', 'quem e']):
                matched_intent = "身份释疑"
                rand_template = random.choice(INTENT_WHO_ARE_YOU_TEMPLATES)
            elif any(k in lower_msg for k in ['como', 'funciona', 'paga', 'verdade', 'golpe', 'quero', 'manda', 'passa', 'link', 'pix', 'onde clica']):
                matched_intent = "玩法/领福利"
                rand_template = random.choice(INTENT_HOW_IT_WORKS_TEMPLATES)
            else:
                matched_intent = "通用问候"
                rand_template = random.choice(SECOND_MESSAGE_TEMPLATES)
            print(f"🧠 [意图识别引擎]: 判定意图为【{matched_intent}】，已匹配精准真人解答话术")

        # 拟人延时与正在输入模拟 (防封核心：1.8~3.5s 自然阅读感，拒绝长时间傻等)
        pre_delay = random.uniform(1.8, 3.5)
        await asyncio.sleep(pre_delay)
        try:
            typing_peer = peer or (await event.get_input_chat() if (event and hasattr(event, 'get_input_chat')) else None) or target_peer
            await client(SetTypingRequest(peer=typing_peer, action=SendMessageTypingAction()))
            await asyncio.sleep(random.uniform(1.2, 2.2))
        except Exception:
            pass
        
        rand_url = get_random_url()
        second_msg = parse_spintax(rand_template)
        if "{URL}" in second_msg:
            second_msg = second_msg.replace("{URL}", rand_url)
        
        # 目标 Peer 寻址：优先使用完整 InputPeer (含 access_hash) 或 event 原生对象，确保 100% 成功送达
        target_peer = peer
        if not target_peer and event is not None:
            try:
                target_peer = await event.get_input_chat()
            except Exception:
                pass
        if not target_peer:
            try:
                target_peer = await client.get_input_entity(chat_id)
            except Exception:
                try:
                    target_peer = await client.get_entity(chat_id)
                except Exception:
                    target_peer = chat_id

        try:
            # 🛡️ 强制 link_preview=False: 彻底禁止 Telegram 服务器爬取敏感博彩/推广 URL，防止触发官方反垃圾风控封号
            if event is not None and hasattr(event, 'respond'):
                try:
                    await event.respond(second_msg, parse_mode='html', link_preview=False)
                except Exception:
                    await event.respond(second_msg, link_preview=False)
            else:
                try:
                    await client.send_message(target_peer, second_msg, parse_mode='html', link_preview=False)
                except Exception:
                    await client.send_message(target_peer, second_msg, link_preview=False)

            print(f"🚀 [自动补发第2条成功] 已向客户 {sender_id} 推送 100 抗封子域名彩金: {rand_url}")
            
            # 仅在真正送达成功后，记录已完成标记
            replied_history[track_key] = incoming_msg_id
            try:
                os.makedirs(os.path.dirname(replied_chats_file), exist_ok=True)
                with open(replied_chats_file, "w", encoding="utf-8") as wf:
                    json.dump(replied_history, wf, ensure_ascii=False, indent=2)
            except Exception:
                pass

            record_auto_reply_stat(
                session_basename=session_basename,
                sender_id=sender_id,
                sender_name=sender_name,
                incoming_msg=msg_text,
                second_msg=second_msg,
                url=rand_url,
                username=username,
                phone=phone,
                first_name=first_name,
                last_name=last_name
            )
        except Exception as e2:
            print(f"❌ [第2条发送失败]: {e2} (目标: {sender_id})")
            return False

        # 判断是否需要发送第 3 阶段中奖祝福语 (默认关闭，仅在客户回复后发送1条聚合落地页链接)
        enable_third = custom_cfg.get("enable_third_message", False)
        if not enable_third:
            print(f"ℹ️ [第3阶段已关闭] 跳过第3条祝福语发送")
            return True

        # 拟人打字 (Typing) 模拟真人输入状态
        delay_min = float(custom_cfg.get("second_to_third_delay_min", 3.5))
        delay_max = float(custom_cfg.get("second_to_third_delay_max", 6.5))
        if delay_max < delay_min:
            delay_max = delay_min + 1.0
        human_delay = random.uniform(delay_min, delay_max)
        print(f"⏳ [模拟真人打字]: 持续输入态 {human_delay:.1f}s 后发送第3阶段频道引流与祝福语...")
        typing_start = time.time()
        while time.time() - typing_start < human_delay:
            try:
                typing_peer = peer or (await event.get_input_chat() if (event and hasattr(event, 'get_input_chat')) else None) or target_peer
                await client(SetTypingRequest(peer=typing_peer, action=SendMessageTypingAction()))
            except Exception:
                pass
            await asyncio.sleep(1.8)

        # 发送第 3 阶段祝福语
        if custom_cfg.get("third_message"):
            third_msg = parse_spintax(custom_cfg.get("third_message"))
        else:
            third_msg = parse_spintax(random.choice(THIRD_BLESSING_TEMPLATES))
            
        try:
            # 🛡️ 强制 link_preview=False: 彻底禁止抓取 Telegram 官方频道/群组预览卡片，防止官方爬虫识别引流违规
            if event is not None and hasattr(event, 'respond'):
                await event.respond(third_msg, link_preview=False)
            else:
                await client.send_message(target_peer, third_msg, link_preview=False)
            print(f"🍀 [自动补发第3条成功] 已向客户 {sender_id} 推送祝福语: \"{third_msg}\"")
        except Exception as e3:
            print(f"❌ [第3条发送失败]: {e3} (目标: {sender_id})")
            return False

        return True
    except Exception as handler_err:
        print(f"⚠️ [处理消息事件异常]: {handler_err}")
        return False

async def start_account_listener(session_path: str, scan_once: bool = False):
    session_basename = os.path.basename(session_path).replace('.session', '')
    clean_digits = re.sub(r'[^0-9]', '', session_basename)
    if clean_digits in BANNED_OBSOLETE_PHONES:
        print(f"🛑 [黑名单过滤] 跳过已弃用/封禁旧号码: +{clean_digits}")
        return

    session_prefix = session_path[:-8] if session_path.endswith('.session') else session_path
    
    # 开启 SQLite WAL 预写日志与并发等待 (30秒超时)，彻底消除多进程 database is locked
    try:
        if os.path.exists(session_path):
            conn = sqlite3.connect(session_path, timeout=30.0)
            conn.execute("PRAGMA journal_mode=WAL;")
            conn.execute("PRAGMA busy_timeout=30000;")
            conn.close()
    except Exception:
        pass
    
    json_path = session_path.replace('.session', '.json')
    json_cfg = {}
    if os.path.exists(json_path):
        try:
            with open(json_path, 'r', encoding='utf-8') as jf:
                json_cfg = json.load(jf)
        except Exception:
            pass

    api_id = int(json_cfg.get("api_id") or json_cfg.get("app_id") or DEFAULT_API_ID)
    api_hash = str(json_cfg.get("api_hash") or json_cfg.get("app_hash") or DEFAULT_API_HASH)
    device_model = str(json_cfg.get("device_model") or "HP Pavilion P6000 Series")
    system_version = str(json_cfg.get("system_version") or "Windows 10")
    app_version = str(json_cfg.get("app_version") or "3.4.3 x64")

    # 智能 100% 巴西专属独享代理分配
    proxy_tuple = get_proxy_for_account(session_basename, json_cfg)

    # 【SQLite 自动备份机制】运行前自动创建 .session.bak 镜像或损坏自愈
    if not backup_and_heal_session(session_path):
        print(f"⚠️ [跳过无效/空文件]: 账号文件 [{session_basename}.session] 并非有效 Telethon 数据库格式且无健康备份。")
        return

    retry_count = 0
    while True:
        # 【读写分离与锁保护】若调度器正在对此账号执行批量群发，主动让出句柄避让，防止 SQLite 锁死与坏块
        if is_session_locked_by_dispatcher(clean_digits):
            print(f"⏸️ [读写分离保护] 账号 +{clean_digits} 当前正由 tg-dispatcher 进行任务发送，自动让出句柄避让 12 秒...")
            await asyncio.sleep(12)
            continue

        client = None
        try:
            print(f"📡 [{'单次扫描' if scan_once else '24h常驻监听'}] 正在挂载并连接账号: {session_basename} ...")
            
            connected_ok = False
            # 1. 优先使用专属配置的巴西独享代理（与群发 IP 保持一致，防止 IP 剧烈跳跃导致官方风控或踢出）
            if proxy_tuple:
                try:
                    client = TelegramClient(
                        session_prefix,
                        api_id,
                        api_hash,
                        proxy=proxy_tuple,
                        device_model=device_model,
                        system_version=system_version,
                        app_version=app_version,
                        connection_retries=3,
                        retry_delay=1,
                        auto_reconnect=True,
                        timeout=15
                    )
                    await asyncio.wait_for(client.connect(), timeout=18.0)
                    connected_ok = True
                except Exception as proxy_err:
                    err_str = str(proxy_err)
                    try:
                        if client:
                            await client.disconnect()
                    except Exception:
                        pass
                    client = None
                    
                    # 针对 Unexpected SOCKS version number: 72 错误，自动秒转 HTTP CONNECT 隧道重试
                    if ("72" in err_str or "SOCKS version" in err_str) and socks and hasattr(socks, 'HTTP'):
                        try:
                            http_tuple = (socks.HTTP, proxy_tuple[1], proxy_tuple[2], *proxy_tuple[3:])
                            client = TelegramClient(
                                session_prefix,
                                api_id,
                                api_hash,
                                proxy=http_tuple,
                                device_model=device_model,
                                system_version=system_version,
                                app_version=app_version,
                                connection_retries=3,
                                retry_delay=1,
                                auto_reconnect=True,
                                timeout=15
                            )
                            await asyncio.wait_for(client.connect(), timeout=18.0)
                            connected_ok = True
                            print(f"✅ [代理自适应] 账号 +{clean_digits} 检测到 HTTP CONNECT 协议 (Port {proxy_tuple[2]})，已自动转换并握手成功！")
                        except Exception:
                            try:
                                if client:
                                    await client.disconnect()
                            except Exception:
                                pass
                            client = None

            # 2. 【安全红线】：若专属代理不可达，尝试巴西住宅备用代理池，绝对禁止 VPS 原生机房 IP 裸连直跑！
            if not connected_ok and len(BRAZIL_PROXY_POOL) > 0:
                try:
                    p_idx = (int(clean_digits[-4:]) if (clean_digits and clean_digits[-4:].isdigit()) else 0) % len(BRAZIL_PROXY_POOL)
                    backup_p_str = BRAZIL_PROXY_POOL[p_idx]
                    backup_tuple = parse_proxy_str(backup_p_str)
                    if backup_tuple:
                        client = TelegramClient(
                            session_prefix,
                            api_id,
                            api_hash,
                            proxy=backup_tuple,
                            device_model=device_model,
                            system_version=system_version,
                            app_version=app_version,
                            connection_retries=2,
                            retry_delay=1,
                            auto_reconnect=True,
                            timeout=15
                        )
                        await asyncio.wait_for(client.connect(), timeout=18.0)
                        connected_ok = True
                except Exception:
                    try:
                        if client:
                            await client.disconnect()
                    except Exception:
                        pass
                    client = None

            # 3. 终极自愈保障：若专属和备用代理不可达，自动无缝切入直连，确保 24h 自动追发雷达 100% 持续在线！
            if not connected_ok:
                try:
                    client = TelegramClient(
                        session_prefix,
                        api_id,
                        api_hash,
                        proxy=None,
                        device_model=device_model,
                        system_version=system_version,
                        app_version=app_version,
                        connection_retries=2,
                        retry_delay=1,
                        auto_reconnect=True,
                        timeout=10
                    )
                    await asyncio.wait_for(client.connect(), timeout=10.0)
                    connected_ok = True
                    print(f"⚡ [直连降级保障] 账号 +{clean_digits} 代理池暂未连通，已切换直连专线确保追发雷达持续在线！")
                except Exception:
                    try:
                        if client:
                            await client.disconnect()
                    except Exception:
                        pass
                    client = None

            if not connected_ok:
                print(f"🛑 账号 +{clean_digits} 连接暂未建立，休眠 10 秒后重试...")
                await asyncio.sleep(10)
                continue

            if not await client.is_user_authorized():
                print(f"⚠️ [未授权] 账号 {session_basename} 未登录或 Session 已失效。")
                if scan_once:
                    try:
                        await client.disconnect()
                    except Exception:
                        pass
                    return
                try:
                    await client.disconnect()
                except Exception:
                    pass
                await asyncio.sleep(60)
                continue
            
            me = await client.get_me()
            phone_num = getattr(me, 'phone', '') or session_basename
            first_name = getattr(me, 'first_name', '') or ''
            print(f"🟢 [{'扫描' if scan_once else '24h守护就绪'}] 账号 +{phone_num} ({first_name}) 自动追发服务在线！")
            retry_count = 0

            # 初始离线历史扫尾与客资同步：检查私聊，同步所有已互动客户资料；若有未回复客户立即补发！
            try:
                dialogs = await client.get_dialogs(limit=30)
                for d in dialogs:
                    if d.is_user and not (getattr(d.entity, 'bot', False)):
                        c_sender_id = str(d.entity.id)
                        c_fn = getattr(d.entity, 'first_name', '') or ''
                        c_ln = getattr(d.entity, 'last_name', '') or ''
                        c_full = " ".join([p for p in [c_fn, c_ln] if p]).strip() or getattr(d.entity, 'username', '') or f"Cliente {c_sender_id}"
                        c_uname = getattr(d.entity, 'username', '') or ''
                        if c_uname and not c_uname.startswith('@'):
                            c_uname = f"@{c_uname}"
                        c_phone = getattr(d.entity, 'phone', '') or ''
                        if c_phone and not c_phone.startswith('+'):
                            c_phone = f"+{c_phone}"

                        c_msgs = await client.get_messages(d.entity, limit=8)
                        if c_msgs:
                            incoming_msgs = [m for m in c_msgs if m and not m.out]
                            if incoming_msgs:
                                latest_incoming = incoming_msgs[0]
                                
                                # ⏰ 严格时效性校验：排除买来的协议号自带的数月前/2025年远古历史聊天
                                msg_date = getattr(latest_incoming, 'date', None)
                                if msg_date:
                                    try:
                                        now_utc = datetime.now(timezone.utc)
                                        if hasattr(msg_date, 'tzinfo') and msg_date.tzinfo is not None:
                                            diff_hours = (now_utc - msg_date).total_seconds() / 3600.0
                                        else:
                                            diff_hours = (datetime.utcnow() - msg_date).total_seconds() / 3600.0
                                        if diff_hours > 48.0:
                                            # 超过 48 小时历史消息，非本次营销互动，跳过
                                            continue
                                    except Exception:
                                        pass

                                c_text = str(latest_incoming.message or latest_incoming.text or '').strip()
                                
                                # 1. 总是持久化/刷新记录到 replied_customers.json (补齐真实的姓名、@username、手机号)
                                save_or_update_replied_customer(
                                    session_basename=session_basename,
                                    sender_id=c_sender_id,
                                    sender_name=c_full,
                                    incoming_msg=c_text,
                                    username=c_uname,
                                    phone=c_phone,
                                    first_name=c_fn,
                                    last_name=c_ln,
                                    msg_date_str=latest_incoming.date.strftime("%Y-%m-%d %H:%M") if hasattr(latest_incoming, 'date') and latest_incoming.date else None
                                )

                                # 2. 检查我们在客户发言后是否已真正投递了彩金链接
                                has_replied_link = False
                                for rm in c_msgs:
                                    if rm and rm.out and rm.id > latest_incoming.id:
                                        rm_text = str(getattr(rm, 'message', '') or getattr(rm, 'text', '') or '')
                                        if 'http' in rm_text or 'promobr' in rm_text or 't.me/' in rm_text or 'Tiger' in rm_text or 'saldo' in rm_text or 'cadastro' in rm_text:
                                            has_replied_link = True
                                            break
                                if not has_replied_link:
                                    await process_and_reply_customer(
                                        client=client,
                                        session_basename=session_basename,
                                        chat_id=d.entity.id,
                                        incoming_msg_id=latest_incoming.id,
                                        msg_text=c_text,
                                        sender_name=c_full,
                                        username=c_uname,
                                        phone=c_phone,
                                        first_name=c_fn,
                                        last_name=c_ln,
                                        peer=d.entity
                                    )
            except Exception as sweep_err:
                print(f"ℹ️ [初始离线扫尾提示]: {sweep_err}")

            if scan_once:
                print(f"✅ 账号 +{phone_num} 扫描客资与补发完毕。")
                return

            # 引擎 1：实时长连接 NewMessage 监听事件
            @client.on(events.NewMessage(incoming=True))
            async def handle_incoming_message(event):
                try:
                    if not event.is_private:
                        return
                    sender = await event.get_sender()
                    fn = getattr(sender, 'first_name', '') or ''
                    ln = getattr(sender, 'last_name', '') or ''
                    full_name = " ".join([p for p in [fn, ln] if p]).strip() or getattr(sender, 'username', '') or f"Cliente {event.chat_id}"
                    uname = getattr(sender, 'username', '') or ''
                    if uname and not uname.startswith('@'):
                        uname = f"@{uname}"
                    uphone = getattr(sender, 'phone', '') or ''
                    if uphone and not uphone.startswith('+'):
                        uphone = f"+{uphone}"

                    msg_text = str(event.text or event.raw_text or "").strip()
                    await process_and_reply_customer(
                        client=client,
                        session_basename=session_basename,
                        chat_id=event.chat_id,
                        incoming_msg_id=getattr(event.message, 'id', 0),
                        msg_text=msg_text,
                        sender_name=full_name,
                        username=uname,
                        phone=uphone,
                        first_name=fn,
                        last_name=ln,
                        event=event,
                        peer=sender or getattr(event.message, 'peer_id', None) or event.chat_id
                    )
                except Exception as e:
                    print(f"⚠️ [事件分发异常]: {e}")

            # 引擎 2（双保险）：后台定时巡检扫尾协程（每 20~30 秒自动巡检一次最近对话，防止网络断流、事件漏推）
            async def background_periodic_sweep():
                while True:
                    try:
                        await asyncio.sleep(random.uniform(20.0, 30.0))
                        if not client.is_connected():
                            continue
                        recent_dialogs = await client.get_dialogs(limit=30)
                        for d in recent_dialogs:
                            if d.is_user and not (getattr(d.entity, 'bot', False)):
                                c_sender_id = str(d.entity.id)
                                c_fn = getattr(d.entity, 'first_name', '') or ''
                                c_ln = getattr(d.entity, 'last_name', '') or ''
                                c_full = " ".join([p for p in [c_fn, c_ln] if p]).strip() or getattr(d.entity, 'username', '') or f"Cliente {c_sender_id}"
                                c_uname = getattr(d.entity, 'username', '') or ''
                                if c_uname and not c_uname.startswith('@'):
                                    c_uname = f"@{c_uname}"
                                c_phone = getattr(d.entity, 'phone', '') or ''
                                if c_phone and not c_phone.startswith('+'):
                                    c_phone = f"+{c_phone}"

                                c_msgs = await client.get_messages(d.entity, limit=4)
                                if c_msgs:
                                    incoming_msgs = [m for m in c_msgs if m and not m.out]
                                    if incoming_msgs:
                                        latest_incoming = incoming_msgs[0]
                                        c_text = str(latest_incoming.message or latest_incoming.text or '').strip()
                                        
                                        # 刷新/同步客资库
                                        save_or_update_replied_customer(
                                            session_basename=session_basename,
                                            sender_id=c_sender_id,
                                            sender_name=c_full,
                                            incoming_msg=c_text,
                                            username=c_uname,
                                            phone=c_phone,
                                            first_name=c_fn,
                                            last_name=c_ln,
                                            msg_date_str=latest_incoming.date.strftime("%Y-%m-%d %H:%M") if hasattr(latest_incoming, 'date') and latest_incoming.date else None
                                        )

                                        if not c_msgs[0].out:
                                            await process_and_reply_customer(
                                                client=client,
                                                session_basename=session_basename,
                                                chat_id=d.entity.id,
                                                incoming_msg_id=latest_incoming.id,
                                                msg_text=c_text,
                                                sender_name=c_full,
                                                username=c_uname,
                                                phone=c_phone,
                                                first_name=c_fn,
                                                last_name=c_ln,
                                                peer=d.entity
                                            )
                    except asyncio.CancelledError:
                        break
                    except Exception as loop_sweep_err:
                        await asyncio.sleep(10.0)

            # 引擎 3（保活心跳）：长连接防假死与心跳探活（每 45 秒向 TG 发送轻量探针，一旦假死立即自愈重连）
            async def background_keep_alive():
                while True:
                    try:
                        await asyncio.sleep(45.0)
                        if client.is_connected():
                            from telethon.tl.functions.updates import GetStateRequest
                            await asyncio.wait_for(client(GetStateRequest()), timeout=10.0)
                    except asyncio.CancelledError:
                        break
                    except Exception as hb_err:
                        print(f"⚠️ [心跳检测到网络断开] 账号 {session_basename}: {hb_err}，立即触发自愈重连...")
                        try:
                            await client.disconnect()
                        except Exception:
                            pass
                        break

            sweep_task = asyncio.create_task(background_periodic_sweep())
            hb_task = asyncio.create_task(background_keep_alive())

            # 🛡️ 群发互斥让出守护：若感知到调度器对此账号发起群发任务，秒级主动让出连接，彻底消除 AuthKeyDuplicated 异地冲突
            async def watch_dispatcher_activity():
                try:
                    while client and client.is_connected():
                        if is_session_locked_by_dispatcher(clean_digits):
                            print(f"⏸️ [感知到群发任务启动] 账号 +{clean_digits} 调度器正挂载发信，守护进程主动断开让出连接...")
                            await client.disconnect()
                            break
                        await asyncio.sleep(0.25)
                except Exception:
                    pass

            lock_task = asyncio.create_task(watch_dispatcher_activity())

            try:
                # 保持长连接常驻
                await client.run_until_disconnected()
                print(f"ℹ️ [连接断开] 账号 {session_basename} 守护连接已断开，3秒后自动重新建立...")
            finally:
                sweep_task.cancel()
                hb_task.cancel()
                lock_task.cancel()

        except Exception as err:
            retry_count += 1
            print(f"⚠️ [账号 {session_basename} 守护异常]: {err}")
            if scan_once:
                return
        finally:
            if client:
                try:
                    await client.disconnect()
                except Exception:
                    pass
            if scan_once:
                return
            await asyncio.sleep(3.0)

async def main():
    scan_once = "--scan-once" in sys.argv
    mode_name = "单次全网扫描补发" if scan_once else "24小时自动追发常驻守护 (Daemon)"
    print("==================================================")
    print(f"🤖 Telegram {mode_name}")
    print("==================================================")

    # 单例进程锁保护（防止后台与 PM2 重复启动两个实例导致 SQLite 文件锁冲突）
    if not scan_once:
        pid_file = os.path.join(os.getcwd(), "sessions", "auto_responder.pid")
        is_pm2 = "PM2_HOME" in os.environ or "pm_id" in os.environ or "PM2_USAGE" in os.environ
        try:
            os.makedirs(os.path.dirname(pid_file), exist_ok=True)
            if os.path.exists(pid_file):
                try:
                    with open(pid_file, "r") as pf:
                        old_pid = int(pf.read().strip())
                    if old_pid != os.getpid():
                        # 检查旧 PID 是否还存活
                        try:
                            os.kill(old_pid, 0)
                            if is_pm2:
                                # 若由 PM2 监管，权威接管终止旧的孤儿后台进程，彻底终结 PM2 循环重启 ↺
                                print(f"🛡️ [PM2 守护接管] 终止旧守护进程 (PID: {old_pid})，由当前主进程权威接管...")
                                import signal
                                os.kill(old_pid, signal.SIGTERM)
                                await asyncio.sleep(1.0)
                            else:
                                print(f"ℹ️ [单例保护] 已有守护实例在运行 (PID: {old_pid})，当前进程直接退出，避免冲突。")
                                return
                        except OSError:
                            pass
                except Exception:
                    pass
            with open(pid_file, "w") as pf:
                pf.write(str(os.getpid()))
        except Exception:
            pass

    script_dir = os.path.dirname(os.path.abspath(__file__))
    possible_dirs = [
        os.path.join(script_dir, "sessions"),
        script_dir,
        os.path.join(os.getcwd(), "sessions"),
        os.getcwd(),
        "/root/tg-dispatcher-v2/sessions",
        "/root/tg-dispatcher-v2",
        "/root/tg-dispatcher/sessions",
        "/root/tg-dispatcher"
    ]

    session_files = []
    seen = set()
    for p_dir in possible_dirs:
        if os.path.exists(p_dir):
            for sf in glob.glob(os.path.join(p_dir, "*.session")):
                basename = os.path.basename(sf)
                digits = re.sub(r'[^0-9]', '', basename)
                if digits in BANNED_OBSOLETE_PHONES:
                    continue
                if sf not in seen and is_valid_telethon_session(sf):
                    seen.add(sf)
                    session_files.append(sf)

    print(f"📱 扫描到已挂载有效账号: {len(session_files)} 个")
    if not session_files:
        print("未发现有效 .session 文件，退出")
        return

    # 并发执行每个账号的独立监听，return_exceptions=True 保证任意单个账号报错不影响集群
    tasks = [start_account_listener(sf, scan_once=scan_once) for sf in session_files]
    await asyncio.gather(*tasks, return_exceptions=True)

if __name__ == "__main__":
    asyncio.run(main())
